# LAST SEEN — Python Web Version

## Run locally
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Put it online with HTTPS
Deploy this folder to a Python host such as Render or Railway. Set a strong `SECRET_KEY` environment variable. The hosting platform will provide an `https://...` URL.

The original WAV sound effects are included in `static/audio/`.
