from flask import Flask, render_template, request, session, redirect, url_for
import os
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY','change-this-before-production')

def init():
    session.setdefault('vars', {'day':1,'lune_trust':0,'kyle_trust':0,'vale_trust':0,'evidence':0,'mika_evidence':0,'toxic_seen':False,'defended_someone':False,'ignored_warning':False,'report_ready':False})
    session.setdefault('node','start')

def go(node, updates=None):
    init(); v=session['vars']
    for k,val in (updates or {}).items(): v[k]=v.get(k,0)+val if isinstance(val,int) and k in v and isinstance(v.get(k),int) else val
    session['vars']=v; session['node']=node

STORY={
'start':('LAST SEEN',['The door closes.','Nara drops her school bag beside the bed.','She falls onto the mattress without taking off her uniform.','Maya: “Nara! Go clean yourself up first!”','Nara: “Yeah...”','Nara looks at the ceiling. She just doesn’t know how to explain what she feels.','BUP. Another notification.','A community recommendation appears: CIRRUS — 37 members • 4 online.'],[('Enter CIRRUS','d1',{})]),
'd1':('DAY 1 — CIRRUS',['0xZERO: hey! welcome new fellow :D','Nara: hii..','lune: welcome nara!! :)','vale: Welcome to CIRRUS, Nara.','What does Nara do?'],[('Say something','d2',{'kyle_trust':1}),('Stay quiet and observe','d2',{})]),
'd2':('DAY 2 — LUNE’S GOSSIP',['lune: can I tell you something?','She tells Nara a rumor about someone from her old school and says she spread it because “people deserved to know.”','The conversation will affect Nara’s relationship with Lune.'],[('Listen to Lune','d3',{'lune_trust':1,'toxic_seen':True}),('Say judging rumors is unfair','d3',{'lune_trust':-1,'defended_someone':True,'toxic_seen':True}),('Change the subject','d3',{'ignored_warning':True,'toxic_seen':True})]),
'd3':('DAY 3 — THE FIRST CRACK',['CIRRUS feels familiar now. Maybe too familiar.','Where does Nara look?'],[('Gaming','gaming',{'kyle_trust':1}),('Off-topic','offtopic',{'toxic_seen':True}),('After-hours','afterhours',{'evidence':1})]),
'gaming':('GAMING',['Kyle jokes about someone who is not online. Lune laughs. Nara hesitates.'],[('Laugh along','d4',{'kyle_trust':1}),('Don’t respond','d4',{'ignored_warning':True})]),
'offtopic':('OFF-TOPIC',['Rumors about someone who is not in the channel fill the chat.'],[('Ask them to stop','d4',{'defended_someone':True,'evidence':1}),('Scroll past','d4',{'ignored_warning':True})]),
'afterhours':('AFTER-HOURS',['vale: Does anyone still remember Mika?','A few seconds later: [message deleted]','Nara takes a screenshot.'],[('Keep investigating','d4',{'mika_evidence':1,'evidence':1})]),
'd4':('DAY 4 — MIKA',['Nara searches the server for one name: MIKA.','Old results show: “Can someone tell them to stop?” “I didn’t say that.” “Why is everyone talking about me?”','Some messages are unavailable.'],[('Open the old messages','lune',{'mika_evidence':2,'evidence':1}),('Close the search','lune',{'ignored_warning':True})]),
'lune':('DAY 4 — QUESTIONS',['Nara asks Lune who Mika was. Lune says: “Don’t dig into things that aren’t yours.”'],[('Ask what happened','d5',{'lune_trust':1,'evidence':1}),('Leave it alone','d5',{'ignored_warning':True})]),
'd5':('DAY 5 — VALE',['Vale messages privately: “You’ve been looking through old channels.”','“Mika’s story is complicated. People make mistakes.”'],[('Trust Vale','d6',{'vale_trust':1}),('Ask how reports were handled','d6',{'evidence':2,'report_ready':True}),('Take screenshots before replying','d6',{'evidence':2,'report_ready':True})]),
'd6':('DAY 6 — THE TRUTH',['Kyle warns Nara to stop asking about Mika.','“Vale knows. And Lune knows more than she’s saying.”'],[('Ask Kyle for everything','final',{'kyle_trust':1,'evidence':1}),('Ask Lune directly','final',{'evidence':3}),('Go to the archive','final',{'evidence':4,'report_ready':True})]),
'final':('FINAL CHOICE',['Nara looks at the folder on her desktop: screenshots, messages, names. Enough to show this was not just one person’s mistake.'],[('Tell Maya everything','home',{}),('Stay and confront everyone','mirror',{}),('Delete everything and pretend nothing happened','silence',{'ignored_warning':True})]),
'home':('ENDING: HOME',['Nara closes CIRRUS and tells Maya everything.','The next morning, the evidence is handed to the proper authorities.','Not everyone apologizes, but someone finally stopped looking away.','Some distances can only be crossed by speaking.'],[('Play again','start',{'reset':True})]),
'mirror':('ENDING: MIRROR',['Nara starts confronting people, then exposing them. Private messages become weapons.','She wanted to stop the cycle, but learns how easy it is to become part of it.','Stopping harm means refusing to pass it on.'],[('Play again','start',{'reset':True})]),
'silence':('ENDING: SILENCE',['Nara deletes the folder and closes the laptop. The server continues.','Another rumor begins. Another person stays silent.','Silence doesn’t end the cycle.'],[('Play again','start',{'reset':True})])}

@app.route('/',methods=['GET','POST'])
def index():
    init()
    if request.method=='POST':
        target=request.form['target']; raw=request.form.get('updates','{}')
        import json; updates=json.loads(raw)
        if updates.pop('reset',False): session.clear(); init()
        go(target,updates); return redirect(url_for('index'))
    title,text,choices=STORY[session['node']]
    return render_template('index.html',title=title,text=text,choices=choices,stats=session['vars'])

if __name__=='__main__': app.run(debug=True)
